#!/system/bin/sh
id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"

source $MODPATH/mod/util_functions.sh

function cads(){
	if test -e "$1" ;then
		rm -rf "$1"
		touch "$1"
		chmod 000 "$1"
		chattr +i "$1"
	fi
}

function recoveryads(){
	if test -e "$1" ;then
		chattr -i "$1"
		chmod 777 "$1"
		rm -rf "$1"
	fi
}

ads_file=(
#豆瓣广告
/data/user/[0-9]*/com.douban.frodo/cache/douban_ad

#驾考宝典
/data/user/[0-9]*/com.handsgo.jiakao.android/cache/GDTDOWNLOAD
/data/media/[0-9]*/Android/data/com.handsgo.jiakao.android/cache/reward_video_cache_*
/data/media/[0-9]*/Android/data/com.handsgo.jiakao.android/cache/splash_ad_cache

#抖音
/data/media/[0-9]*/Android/data/com.ss.android.ugc.aweme/awemeSplashCache
/data/media/[0-9]*/Android/data/com.ss.android.ugc.aweme/liveSplashCache
/data/media/[0-9]*/Android/data/com.ss.android.ugc.aweme/splashCache


#QQ浏览器
/data/user/[0-9]*/com.tencent.mtt/files/tad_cache

#QQ音乐
/data/user/[0-9]*/com.tencent.qqmusic/app_adnet
/data/user/[0-9]*/com.tencent.qqmusic/files/tad_cache
/data/media/[0-9]*/qqmusic/splash

#人人影视PRO
/data/user/[0-9]*/com.yyets.pro/app_ad

#酷安
/data/media/[0-9]*/Android/data/com.coolapk.market/cachett_ad
/data/media/[0-9]*/Android/data/com.coolapk.market/cache/splash_image
/data/media/[0-9]*/Android/data/com.coolapk.market/cache/com_qq_e_download
/data/media/[0-9]*/Android/data/com.coolapk.market/cache/pangle_com.byted.pangle
/data/media/[0-9]*/Android/data/com.coolapk.market/cache/tt_tmpl_pkg
/data/media/[0-9]*/Android/data/com.coolapk.market/files/TTCache
/data/media/[0-9]*/Android/data/com.coolapk.market/cache/com.jd.jdsdk

#keep
/data/media/[0-9]*/Android/data/com.gotokeep.keep/files/keep/ads

#网易云
/data/media/[0-9]*/Android/data/com.netease.cloudmusic/cache/Ad
/data/media/[0-9]*/netease/adcache
/data/media/[0-9]*/netease/cloudmusic/Ad

#今日头条
/data/media/[0-9]*/Android/data/com.ss.android.article.news/splashCache

#腾讯微视
/data/media/[0-9]*/Android/data/com.tencent.weishi/splash_cache

#QQ
/data/media/[0-9]*/Tencent/MobileQQ/splahAD
/data/media/[0-9]*/Tencent/TMAssistantSDK
/data/media/[0-9]*/Android/data/com.tencent.mobileqq/Tencent/TMAssistantSDK
/data/media/[0-9]*/Android/data/com.tencent.mobileqq/MobileQQ/splahAD
/data/media/[0-9]*/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/vasSplashAD

#高德地图
/data/media/[0-9]*/autonavi/afpSplash
/data/media/[0-9]*/autonavi/splash
/data/media/[0-9]*/Android/data/com.autonavi.minimap/cache/ajxFileDownload/
/data/user/[0-9]*/com.autonavi.minimap/files/splash

#酷狗音乐
/data/media/[0-9]*/kugou/.splash
/data/media/[0-9]*/Android/data/com.kugou.android/files/kugou/.splash

#微博
/data/media/[0-9]*/sina/weibo/.weibo_ad_universal_cache
/data/media/[0-9]*/sina/weibo/.weibo_refreshad_cache
/data/media/[0-9]*/sina/weibo/.weibo_video_cache_new
/data/media/[0-9]*/sina/weibo/.weiboadcache
/data/media/[0-9]*/sina/weibo/storage/biz_keep/.weibo_ad_universal_cache
/data/media/[0-9]*/sina/weibo/storage/biz_keep/.weibo_refreshad_cache

#淘宝
/data/media/[0-9]*/Android/data/com.taobao.taobao/files/acds


#咪咕的各类应用
/data/media/[0-9]*/Mob

#MIUI
/data/media/[0-9]*/miad
/data/media/[0-9]*/Android/data/com.miui.systemAdSolution/files/miad

#bilibili
/data/user/[0-9]*/tv.danmaku.bili/files/res_cache

#有道词典
/data/media/[0-9]*/Android/data/com.youdao.dict/files/yd_sdk_path
#邮箱大师
/data/user/[0-9]*/com.netease.mail/cache/adcache1
/data/user/[0-9]*/com.netease.mail/cache/adcache

#美团
/data/user/[0-9]*/com.sankuai.meituan/files/cips/common/mtplatform_group/assets/startup

#饿了么
/data/user/[0-9]*/me.ele/cache/splash
/data/user/[0-9]*/me.ele/files/o2o_ad

#百度网盘
/data/user/[0-9]*/com.baidu.netdisk/files/default_ad_caches
/data/user/[0-9]*/com.baidu.netdisk/cache/wind
/data/user/[0-9]*/com.baidu.netdisk/files/imgCache
/data/user/[0-9]*/com.baidu.netdisk/files/splash_res_caches
/data/user/[0-9]*/com.baidu.netdisk/files/video_front_ad_caches
/data/user/[0-9]*/com.baidu.netdisk/files/splash

#中国移动
/data/user/[0-9]*/com.greenpoint.android.mc10086.activity/cache/image_manager_disk_cache
#移动云盘
/data/media/[0-9]*/Android/data/com.chinamobile.mcloud/files/boot_logo
#飞猪旅行
/data/user/[0-9]*/com.taobao.trip/files/fliggy_splash
#携程旅行
/data/media/[0-9]*/Android/data/ctrip.android.view/cache/CTADCache
)

if test $(show_value "chattr锁定") == 是 ;then
	for ads in ${ads_file[@]}
	do
		cads "${ads}"
	done
else
	for ads in ${ads_file[@]}
	do
		mkdir_file "${ads}"
	done
fi