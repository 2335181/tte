XM=$(cat /data/system/packages.list | grep com.miui.packageinstaller | awk '{print $2}')
MZ=$(cat /data/system/packages.list | grep com.android.packageinstaller | awk '{print $2}')
FZ=$(cat /data/system/packages.list | grep com.hicorenational.antifraud | awk '{print $2}')
CS=$(cat /data/system/packages.list | grep webapp.pingbiceshi | awk '{print $2}')
XM2=$(cat /data/system/packages.list | grep com.miui.guardprovider | awk '{print $2}')
ColorOS=$(cat /data/system/packages.list | grep com.coloros.phonemanager | awk '{print $2}')
ColorOS2=$(cat /data/system/packages.list | grep com.oplus.appdetail | awk '{print $2}')
MZ2=$(cat /data/system/packages.list | grep com.meizu.safe | awk '{print $2}')
OriginOS=$(cat /data/system/packages.list | grep com.vivo.safecenter | awk '{print $2}')
OriginOS2=$(cat /data/system/packages.list | grep com.iqoo.secure | awk '{print $2}')
OriginOS3=$(cat /data/system/packages.list | grep com.vivo.sdkplugin | awk '{print $2}')



# 屏蔽安装器上传
iptables -t nat -I OUTPUT -m owner --uid-owner=$ColorOS2 -p tcp -d 0.0.0.0/0 -j DNAT --to-destination 127.0.0.1:8848 >/dev/null 2>&1
iptables -t nat -I OUTPUT -m owner --uid-owner=$ColorOS -p tcp -d 0.0.0.0/0 -j DNAT --to-destination 127.0.0.1:8848 >/dev/null 2>&1
iptables -t nat -I OUTPUT -m owner --uid-owner=$CS -p tcp -d 0.0.0.0/0 -j DNAT --to-destination 127.0.0.1:8848 >/dev/null 2>&1
iptables -t nat -I OUTPUT -m owner --uid-owner=$FZ -p tcp -d 0.0.0.0/0 -j DNAT --to-destination 127.0.0.1:8848 >/dev/null 2>&1
iptables -t nat -I OUTPUT -m owner --uid-owner=$MZ -p tcp -d 0.0.0.0/0 -j DNAT --to-destination 127.0.0.1:8848 >/dev/null 2>&1
iptables -t nat -I OUTPUT -m owner --uid-owner=$XM -p tcp -d 0.0.0.0/0 -j DNAT --to-destination 127.0.0.1:8848 >/dev/null 2>&1
iptables -t nat -I OUTPUT -m owner --uid-owner=$XM2 -p tcp -d 0.0.0.0/0 -j DNAT --to-destination 127.0.0.1:8848 >/dev/null 2>&1
iptables -t nat -I OUTPUT -m owner --uid-owner=$MZ2 -p tcp -d 0.0.0.0/0 -j DNAT --to-destination 127.0.0.1:8848 >/dev/null 2>&1
iptables -t nat -I OUTPUT -m owner --uid-owner=$OriginOS -p tcp -d 0.0.0.0/0 -j DNAT --to-destination 127.0.0.1:8848 >/dev/null 2>&1
iptables -t nat -I OUTPUT -m owner --uid-owner=$OriginOS2 -p tcp -d 0.0.0.0/0 -j DNAT --to-destination 127.0.0.1:8848 >/dev/null 2>&1
iptables -t nat -I OUTPUT -m owner --uid-owner=$OriginOS3 -p tcp -d 0.0.0.0/0 -j DNAT --to-destination 127.0.0.1:8848 >/dev/null 2>&1

list="
#谷歌和doubleclick广告
#doubleclick.net
#admaster
#admaster.com.cn
#囧次元
116.205.193.167
#211.157.171.237
#211.151.146.65
#迅雷
#x-api-shoulei.xunlei.com
#x.xunlei.com
#作业帮
httpdns.zybang.com
#反诈中心
49.7.228.53
14.29.101.168
14.29.101.160
14.29.101.169
116.177.251.215
218.77.192.51
111.20.26.186
112.84.130.73
61.243.26.3
116.142.251.100
111.51.90.173
183.236.60.105
101.206.203.174
117.31.116.57
180.163.200.99
106.227.26.33
117.185.20.168
101.69.129.138
39.175.224.40
219.152.87.101
59.49.8.24
223.109.224.43
123.151.98.175
125.74.134.73
182.242.56.70
58.49.156.81
36.158.196.25
111.7.90.97
183.204.227.3
113.137.43.167
218.77.192.52
118.213.92.50
106.41.206.93
171.105.185.55
111.7.93.60
125.39.177.94
122.189.237.9
61.243.26.6
116.177.251.217
60.223.222.162
111.10.52.133
116.162.201.81
116.177.251.216
36.147.40.195
113.125.253.37
221.15.69.47
36.147.27.2
36.249.80.86
123.159.206.44
42.248.133.67
111.48.28.46
113.62.113.46
117.161.138.96
183.201.224.91
111.31.73.182
111.44.252.226
112.240.59.154
153.101.175.200
157.255.34.28
112.48.168.3
1.58.38.6
27.221.54.107
61.135.15.244
183.136.140.25
221.15.69.48
121.228.190.70
42.101.23.53
218.60.173.133
111.44.252.225
111.44.252.227
111.40.177.172
180.163.200.98
106.227.26.32
101.69.129.241
113.24.209.160
125.74.134.74
27.18.12.6
113.249.87.131
111.20.26.185
113.140.36.110
182.242.56.150
106.41.206.92
118.213.92.48
111.10.52.131
116.162.201.82
123.159.206.46
61.243.26.5
113.125.253.40
112.240.59.155
113.62.113.44
111.48.63.25
111.51.90.174
112.17.17.42
1.180.31.27
157.255.34.2
111.29.43.91
36.99.183.88
218.60.173.130
182.40.45.81
36.110.220.114
101.206.203.173
118.123.20.64
111.62.158.220
223.242.37.43
111.26.56.89
124.236.19.61
112.29.213.66
36.131.159.224
60.9.4.220
124.232.180.181
222.75.4.141
58.217.200.222
210.22.248.223
223.111.138.3
36.99.23.32
121.228.190.68
111.26.56.86
117.31.116.58
223.109.62.200
116.142.251.101
110.156.168.131
117.31.116.59
112.17.17.79
36.99.23.31
111.40.177.173
118.123.208.152
124.236.19.60
1.180.22.180
111.62.158.195
111.29.43.90
140.249.153.85
111.40.177.171
60.9.4.195
36.110.220.111
120.201.235.30
124.232.139.148
222.75.36.76
117.31.116.56
121.228.190.71
210.22.248.224
110.156.168.146
223.109.62.202
#国家平台
125.124.253.96
183.214.10.166
125.124.253.95
223.247.113.70
171.105.187.88
223.247.113.71
223.109.62.223
27.128.213.69
111.63.181.104
27.128.213.68
111.7.72.254
183.214.10.165
223.109.62.222
222.75.36.98
36.110.220.144
180.105.72.174
125.77.181.205
36.112.20.111
219.144.24.93
58.63.255.244
27.18.12.94
171.105.187.89
218.77.192.67
122.228.102.60
42.185.159.95
27.18.12.93
222.75.36.97
111.7.93.70
36.110.220.145
124.232.139.238
58.216.30.215
117.31.118.45
58.63.255.243
117.31.118.44
110.156.169.155
42.248.133.83
42.185.159.96
111.62.149.141
112.84.222.66
59.110.245.79
36.158.231.188
124.238.251.162
119.39.205.15
122.228.102.59
211.103.220.221
203.34.106.144
202.127.0.105
127.0.0.2
42.202.155.142
116.211.128.111
59.63.226.15
180.105.72.173
124.225.91.29
111.7.93.69
42.248.133.84
125.77.181.206
124.232.160.126
110.156.169.153
124.232.160.125
111.7.93.68
#备案域名
112.84.222.56
111.62.149.129
119.39.205.85
27.155.113.108
124.238.251.188
116.211.128.178
36.158.231.210
112.45.27.156
42.202.155.215
59.63.226.86
#偷文件
120.76.141.58
"
local IFS=$'\n'

for i in ${list}
do

if test "$(echo "${i}" | grep '^#')" != "" ;then
	continue
elif test "$(echo "${i}" | grep -Eo '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}')" != "" ;then
	iptables -D OUTPUT -d "${i}" -j DROP >/dev/null 2>&1
	iptables -A OUTPUT -d "${i}" -j DROP
#	iptables -D OUTPUT -d "${i}" -j DROP
elif test "$(echo "${i}" | grep -E '^\*\.')" != "" ;then
	iptables -D OUTPUT -m tls --tls-host "${i}" -j DROP >/dev/null 2>&1
	iptables -A OUTPUT -m tls --tls-host "${i}" -j DROP
#	iptables -D OUTPUT -m tls --tls-host "${i}" -j DROP
else
	iptables -D OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP >/dev/null 2>&1
	iptables -A OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
#	iptables -D OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
fi

done 

