#!/system/bin/sh

id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"

source $MODPATH/mod/util_functions.sh

find /sdcard/Android/data/com.alicloud.databox /data/user/0/com.alicloud.databox -iname '*log*' -type d | while read Folder ;do
	test -d "${Folder}" && mkdir_file "${Folder}"
done


find /sdcard/Android/data/com.alicloud.databox /data/user/0/com.alicloud.databox -iname '*crash*' -type f -o -iname "*.log" -type f -o -iname "*.xlog" -type f -o -iname "*.logs" -type f 2>/dev/null | while read File ;do
	test -f "${File}" && rm -rf "${File}"
done



