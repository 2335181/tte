id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"

source $MODPATH/mod/util_functions.sh

package_name=(
com.xiaomi.ab
com.miui.analytics
com.opos.ad
com.opos.ads
)

function disable_apps(){
local package="${1}"
test "${2}" = "" && return 0
if test "${2}" = "disable" ;then
	pm disable "${package}" >/dev/null 2>&1
	pm hide "${package}" >/dev/null 2>&1
else
	pm unhide "${package}" >/dev/null 2>&1
	pm enable "${package}" >/dev/null 2>&1
fi
}


for i in ${package_name[@]}
do
	disable_apps "${i}" "disable"
done


if test "$( show_value 'MIUI智能服务' )" != "启用" ;then
	disable_apps "com.miui.systemAdSolution" "disable"
else
	#恢复小米com.miui.systemAdSolution的启动
	disable_apps "com.miui.systemAdSolution"
fi