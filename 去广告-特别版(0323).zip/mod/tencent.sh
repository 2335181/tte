id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"

source $MODPATH/mod/util_functions.sh

#运行删除腾讯监视文件，没有禁止写入
#如有需要就自己把X_FILE_RE改成X_FILE_DIR
#注意如果禁止写入，请禁用MIUI 手机管家的任何引擎。
#如腾讯杀毒引擎，腾讯清理引擎，不然就会引起相关组件
#cpu 占用100%
if test $(show_value "chattr锁定") == 是 ;then
	find /data/media /data/data /data/user /data/user_de -iname "turing.dat" -type f -o -iname ".tmfs" -type d 2>/dev/null | while read path ;do
		X_file "${path}"
	done
else 
	find /data/media /data/data /data/user /data/user_de -iname "turing.dat" -type f -o -iname ".tmfs" -type d 2>/dev/null | while read path ;do
		mkdir_file "${path}"
	done
fi